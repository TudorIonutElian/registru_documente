<?php 
    require './includes/header.php' ;
    require './includes/navbar.php' ;
?>

    <div id="main-content-registru">
        
    </div>

    </div>

    <?php require './includes/footer.php'; ?>
