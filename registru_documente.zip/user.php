<div class="container-fluid container-flex" >
            <div class="row">
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=n">
                            <div><img src="img/n.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Registru Neclasificate</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=ssv">
                            <div><img src="img/ssv.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Registru SSv</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=s">
                            <div><img src="img/s.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Registru S</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=ss">
                            <div><img src="img/ss.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Registru SS</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=p">
                            <div><img src="img/p.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Registru Petitii</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
                <div class="col-2 mt-3">
                    <div class="box-registru">
                        <a class="text-center" href="documente.php?registru=a">
                            <div><img src="img/p.png" alt=""></div>
                            <div class="btn btn-primary btn-sm">Adeverinte diverse</div>
                            <div>0 numere / 0 alocate</div>
                            <div>0% utilizat</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>